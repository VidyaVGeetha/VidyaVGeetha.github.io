const GITHUB_REPOS_API = "https://api.github.com/users/VidyaVGeetha/repos?per_page=100&sort=updated";

const fallbackProjects = [
  ["powerbi-sales-marketing-dashboard", "Power BI dashboard analysing sales performance, regional trends, and marketing effectiveness with interactive KPIs and insights.", "https://github.com/VidyaVGeetha/powerbi-sales-marketing-dashboard", "Power BI", "2026-04-14"],
  ["powerbi-sales-performance-customer-insights-dashboard", "Interactive Power BI report with a dashboard-style layout analyzing sales performance, customer behavior, and order trends using data modeling, DAX, and interactive visuals.", "https://github.com/VidyaVGeetha/powerbi-sales-performance-customer-insights-dashboard", "Power BI", "2026-04-14"],
  ["powerbi-sales-aggregation-performanceOptimization", "Optimized Power BI report performance by creating aggregated tables using Power Query and implementing an efficient data model to reduce query load and improve dashboard responsiveness.", "https://github.com/VidyaVGeetha/powerbi-sales-aggregation-performanceOptimization", "Power BI", "2026-03-31"],
  ["nhs-healthcare-analytics-powerbi", "NHS healthcare analytics project built in Power BI, featuring admissions trends, department analysis, and time intelligence.", "https://github.com/VidyaVGeetha/nhs-healthcare-analytics-powerbi", "Power BI", "2026-03-26"],
  ["powerbi-role-playing-dimension-sales-analysis", "Power BI project demonstrating role-playing dimensions and USERELATIONSHIP for analyzing sales by shipping date using AdventureWorks.", "https://github.com/VidyaVGeetha/powerbi-role-playing-dimension-sales-analysis", "Power BI", "2026-03-18"],
  ["powerbi-sales-running-total-analysis", "Power BI project analyzing AdventureWorks sales performance using DAX measures, running totals, and revenue calculations.", "https://github.com/VidyaVGeetha/powerbi-sales-running-total-analysis", "Power BI", "2026-03-15"],
  ["powerbi-quarterly-sales-analysis", "Power BI learning project analyzing AdventureWorks sales data with data modeling, DAX columns, and sales patterns.", "https://github.com/VidyaVGeetha/powerbi-quarterly-sales-analysis", "Power BI", "2026-03-13"],
  ["powerbi-dax-customer-churn-risk-analysis", "Customer churn risk detection using Power BI and DAX logical functions for business rules and risk segmentation.", "https://github.com/VidyaVGeetha/powerbi-dax-customer-churn-risk-analysis", "Power BI", "2026-03-12"],
  ["powerbi-adventureworks-star-schema-model", "Star schema data model in Power BI using AdventureWorks for scalable sales analytics.", "https://github.com/VidyaVGeetha/powerbi-adventureworks-star-schema-model", "Power BI", "2026-03-10"],
  ["powerbi-etl-sales-data-transformation-adventureworks", "End-to-end ETL in Power BI Power Query for cleaning, merging, anomaly detection, and profiling.", "https://github.com/VidyaVGeetha/powerbi-etl-sales-data-transformation-adventureworks", "Power BI", "2026-03-06"],
  ["powerbi-sales-data-profiling", "Power Query data profiling, validation, locale currency transformation, and column-level quality checks.", "https://github.com/VidyaVGeetha/powerbi-sales-data-profiling", "Power BI", "2026-03-05"],
  ["powerbi-sales-product-merge-analysis", "Power Query merge workflow using joins to enrich sales data with product attributes.", "https://github.com/VidyaVGeetha/powerbi-sales-product-merge-analysis", "Power BI", "2026-03-02"],
  ["powerbi-sales-data-consolidation", "Sales data consolidation using Power Query append after a business acquisition scenario.", "https://github.com/VidyaVGeetha/powerbi-sales-data-consolidation", "Power BI", "2026-02-27"],
  ["powerbi-product-color-analysis", "Pivot and unpivot transformations in Power Query for a product color analysis dashboard.", "https://github.com/VidyaVGeetha/powerbi-product-color-analysis", "Power BI", "2026-02-27"],
  ["PowerBI_sales_data_transformation", "Power Query cleaning and transformation project covering missing values, data types, categories, and duplicates.", "https://github.com/VidyaVGeetha/PowerBI_sales_data_transformation", "Power BI", "2026-02-26"],
  ["PowerBI-AdventureWorks-Sales-Dashboard", "Interactive sales performance dashboard in Power BI for product categories, order totals, and revenue distribution.", "https://github.com/VidyaVGeetha/PowerBI-AdventureWorks-Sales-Dashboard", "Power BI", "2026-02-19"],
  ["IBM-Cognos-Survey-Analytics-Dashboard", "IBM Cognos analytics project with Python-cleaned survey data and multi-tab dashboards.", "https://github.com/VidyaVGeetha/IBM-Cognos-Survey-Analytics-Dashboard", "Jupyter Notebook", "2026-01-24"],
  ["ibm-cognos-sales-dashboard", "Sales performance dashboard built in IBM Cognos Analytics for IBM Data Analyst coursework.", "https://github.com/VidyaVGeetha/ibm-cognos-sales-dashboard", "IBM Cognos", "2026-01-21"],
  ["Data-Visualization---Career-and-Technology-Trends-in-Developer-Survey", "Developer survey visualisation project covering roles, compensation, technology preferences, and programming time.", "https://github.com/VidyaVGeetha/Data-Visualization---Career-and-Technology-Trends-in-Developer-Survey", "Jupyter Notebook", "2026-01-17"],
  ["global-salary-analysis-outlier-detection", "EDA of global developer salary survey data with IQR outlier detection and compensation distributions.", "https://github.com/VidyaVGeetha/global-salary-analysis-outlier-detection", "Jupyter Notebook", "2026-01-13"],
  ["stackdev-analytics", "Large-scale developer survey cleaning, transformation, exploratory analysis, visualization, and correlation analysis.", "https://github.com/VidyaVGeetha/stackdev-analytics", "Jupyter Notebook", "2026-01-12"],
  ["stackoverflow-survey-analysis-project", "Stack Overflow survey analysis covering experience, job satisfaction, remote work, education, and employment.", "https://github.com/VidyaVGeetha/stackoverflow-survey-analysis-project", "Jupyter Notebook", "2026-01-06"],
  ["survey-data-cleaning-and-feature-engineering", "Survey wrangling and feature engineering with missing values, duplicates, encoding, compensation scaling, and EDA.", "https://github.com/VidyaVGeetha/survey-data-cleaning-and-feature-engineering", "Jupyter Notebook", "2026-01-04"],
  ["stackoverflow-survey-data-cleaning-normalization", "Developer survey preprocessing with duplicate removal, missing-value analysis, and salary normalization.", "https://github.com/VidyaVGeetha/stackoverflow-survey-data-cleaning-normalization", "Jupyter Notebook", "2026-01-02"],
  ["Stack-Overflow-Survey-Data-Cleaning-Duplicates-Missing-Values-Handling", "Data cleaning notebook for duplicate detection, missing values, and compensation column identification.", "https://github.com/VidyaVGeetha/Stack-Overflow-Survey-Data-Cleaning-Duplicates-Missing-Values-Handling", "Jupyter Notebook", "2026-01-01"],
  ["Stack-Overflow-Survey-Missing-Values-Analysis-Employment-Imputation", "Missing-value analysis and employment imputation using mode, with top employment category visualization.", "https://github.com/VidyaVGeetha/Stack-Overflow-Survey-Missing-Values-Analysis-Employment-Imputation", "Jupyter Notebook", "2026-01-01"],
  ["survey-data-cleaning-and-analysis", "Survey data cleaning and analysis with duplicate removal, missing values, and normalized salary insights.", "https://github.com/VidyaVGeetha/survey-data-cleaning-and-analysis", "Jupyter Notebook", "2025-12-31"],
  ["survey-duplicate-detection-and-data-cleaning-python", "Python and Pandas case study for identifying, analyzing, and removing duplicate survey records.", "https://github.com/VidyaVGeetha/survey-duplicate-detection-and-data-cleaning-python", "Jupyter Notebook", "2025-12-31"],
  ["programming-language-salary-analysis-web-scraping", "Web scraping and analysis project using Requests and BeautifulSoup to build a programming language salary report.", "https://github.com/VidyaVGeetha/programming-language-salary-analysis-web-scraping", "Jupyter Notebook", "2025-12-29"],
  ["web-data-extraction-links-images-tables", "Web scraping mini-project extracting links, images, and table data with Python, Requests, and BeautifulSoup.", "https://github.com/VidyaVGeetha/web-data-extraction-links-images-tables", "Jupyter Notebook", "2025-12-28"],
  ["job-market-analysis-using-apis-python", "Job market analysis using a Flask API, Python, Pandas, skill demand analysis, and Excel export.", "https://github.com/VidyaVGeetha/job-market-analysis-using-apis-python", "Jupyter Notebook", "2025-12-28"],
  ["python-api-requests-lab", "HTTP GET and POST requests lab using Python Requests, headers, parameters, JSON, and downloads.", "https://github.com/VidyaVGeetha/python-api-requests-lab", "Jupyter Notebook", "2025-12-27"],
  ["astronaut-api-data-exploration", "Public API exploration project retrieving astronaut data, parsing JSON, and extracting current spaceflight insights.", "https://github.com/VidyaVGeetha/astronaut-api-data-exploration", "Jupyter Notebook", "2025-12-27"],
  ["automobile-sales-analysis-dashboard", "Interactive Python, Plotly, and Dash dashboard analyzing automobile sales trends during recession and non-recession periods.", "https://github.com/VidyaVGeetha/automobile-sales-analysis-dashboard", "Python", "2025-12-22"],
  ["NHS_Prescription_Data_Analysis", "NHS prescription dataset analysis for regional and time-period trends with KPI insights.", "https://github.com/VidyaVGeetha/NHS_Prescription_Data_Analysis", "Jupyter Notebook", "2025-12-22"],
  ["Tesla-GameStop-Stock-Analysis", "Stock and revenue data extraction and visualization for Tesla and GameStop using yfinance, scraping, and Plotly.", "https://github.com/VidyaVGeetha/Tesla-GameStop-Stock-Analysis", "Python", "2025-12-22"],
  ["flight-delay-dashboard", "Interactive Dash and Plotly dashboard analyzing US airline delay causes by year.", "https://github.com/VidyaVGeetha/flight-delay-dashboard", "Python", "2025-12-22"],
  ["recession-impact-on-automobile-sales", "EDA of synthetic automobile sales data to quantify recession impacts with Pandas, Seaborn, and Folium.", "https://github.com/VidyaVGeetha/recession-impact-on-automobile-sales", "Jupyter Notebook", "2025-12-21"],
  ["australia-wildfire-dashboard-analysis", "Interactive dashboard and EDA of Australian wildfire activity using Dash, Plotly, and Pandas.", "https://github.com/VidyaVGeetha/australia-wildfire-dashboard-analysis", "Python", "2025-12-15"],
  ["australia-wildfire-analysis-python", "Historical wildfire activity analysis in Australia using Pandas, Seaborn, Matplotlib, and Folium.", "https://github.com/VidyaVGeetha/australia-wildfire-analysis-python", "Jupyter Notebook", "2025-12-13"],
  ["scotland-uk-airport-recovery-dashboard", "Streamlit dashboard analyzing Scotland airport recovery from COVID-19 against major UK hubs.", "https://github.com/VidyaVGeetha/scotland-uk-airport-recovery-dashboard", "Jupyter Notebook", "2025-12-05"],
  ["Plotly-Visualizations-Beginners", "Beginner-friendly collection of interactive charts built with Python and Plotly.", "https://github.com/VidyaVGeetha/Plotly-Visualizations-Beginners", "Jupyter Notebook", "2025-11-29"],
  ["IMIGRATION_APP", "Python app project related to immigration data workflows.", "https://github.com/VidyaVGeetha/IMIGRATION_APP", "Python", "2025-11-25"],
  ["treemap-visualization-sales", "Treemap visualization using Python, Pandas, and Plotly Express for hierarchical sales analysis.", "https://github.com/VidyaVGeetha/treemap-visualization-sales", "Jupyter Notebook", "2025-11-18"],
  ["san-francisco-crime-mapping-folium", "Geospatial crime mapping project using Python, Pandas, Folium, popups, basemaps, and marker clustering.", "https://github.com/VidyaVGeetha/san-francisco-crime-mapping-folium", "Jupyter Notebook", "2025-11-18"],
  ["uk-used-car-price-regression", "EDA and regression modeling of UK used car prices using mileage, year, and engine-size drivers.", "https://github.com/VidyaVGeetha/uk-used-car-price-regression", "Jupyter Notebook", "2025-11-13"],
  ["seaborn-categorical-plots-canada-immigration", "Categorical visualization showcase with Seaborn using Canada immigration data.", "https://github.com/VidyaVGeetha/seaborn-categorical-plots-canada-immigration", "Jupyter Notebook", "2025-11-12"],
  ["WordCloud-Analysis-Canada_Immigration", "Word cloud visualization of immigration trends to Canada from 1980 to 2013.", "https://github.com/VidyaVGeetha/WordCloud-Analysis-Canada_Immigration", "Jupyter Notebook", "2025-11-11"],
  ["Aice-wordcloud-text-visualization", "Word cloud text visualization of Alice's Adventures in Wonderland with masks and stopword cleaning.", "https://github.com/VidyaVGeetha/Aice-wordcloud-text-visualization", "Jupyter Notebook", "2025-11-11"],
  ["Alice-wordcloud-text-visualization", "Word cloud text visualization of Alice's Adventures in Wonderland.", "https://github.com/VidyaVGeetha/Alice-wordcloud-text-visualization", "Visualization", "2025-11-11"],
  ["Waffle-Chart-Visualization-in-Python-Using-Matplotlib-and-PyWaffle", "Canada immigration waffle chart project using Matplotlib and PyWaffle.", "https://github.com/VidyaVGeetha/Waffle-Chart-Visualization-in-Python-Using-Matplotlib-and-PyWaffle", "Jupyter Notebook", "2025-11-10"],
  ["github-portfolio", "GitHub portfolio repository.", "https://github.com/VidyaVGeetha/github-portfolio", "Portfolio", "2025-10-05"],
  ["data-visualization-canada-immigration", "Canadian immigration visualization project focused on countries with the lowest immigration counts.", "https://github.com/VidyaVGeetha/data-visualization-canada-immigration", "Jupyter Notebook", "2025-08-21"],
  ["House-Sales-Price-Analysis-King-County-USA", "King County house sales analysis with data cleaning, EDA, and predictive modeling.", "https://github.com/VidyaVGeetha/House-Sales-Price-Analysis-King-County-USA", "Jupyter Notebook", "2025-08-15"],
  ["canada-immigration-data-analysis", "Canada immigration data analysis and visualization from 1980 to 2013 using Pandas and Matplotlib.", "https://github.com/VidyaVGeetha/canada-immigration-data-analysis", "Jupyter Notebook", "2025-08-15"],
  ["Car-Cost-Prediction", "Car cost prediction notebook project.", "https://github.com/VidyaVGeetha/Car-Cost-Prediction", "Jupyter Notebook", "2025-08-09"],
  ["Health-Insurance-Cost-Analysis", "Health insurance cost analysis exploring age, BMI, smoking, children, and medical charges.", "https://github.com/VidyaVGeetha/Health-Insurance-Cost-Analysis", "Jupyter Notebook", "2025-08-04"],
  ["Chicago-Crime-Census-School-Analysis", "SQL and Python analysis of Chicago crime, census, and public school datasets.", "https://github.com/VidyaVGeetha/Chicago-Crime-Census-School-Analysis", "Jupyter Notebook", "2025-07-12"],
  ["SQL-Data-Exploration-ChicagoSchools", "SQL-based analysis of Chicago Public Schools data with SQLite and Jupyter.", "https://github.com/VidyaVGeetha/SQL-Data-Exploration-ChicagoSchools", "Python", "2025-07-08"],
  ["Instructor-Insights-A-SQLite-Powered-Data-Exploration-", "SQLite-powered data exploration project for instructor insights.", "https://github.com/VidyaVGeetha/Instructor-Insights-A-SQLite-Powered-Data-Exploration-", "Python", "2025-07-04"],
  ["Socioeconomic-Trends-with-Python", "Socioeconomic trends analysis using Python.", "https://github.com/VidyaVGeetha/Socioeconomic-Trends-with-Python", "Python", "2025-07-04"],
  ["SQL", "SQL practice and portfolio repository.", "https://github.com/VidyaVGeetha/SQL", "HTML", "2025-06-27"],
  ["city-metrics-visualizer", "Interactive visualization dashboard comparing population, economic indicators, and urban statistics.", "https://github.com/VidyaVGeetha/city-metrics-visualizer", "Jupyter Notebook", "2025-04-19"],
  ["Live_AQI_Dashboard", "Live air quality dashboard project.", "https://github.com/VidyaVGeetha/Live_AQI_Dashboard", "Jupyter Notebook", "2025-04-19"],
  ["Student_Scrrentime", "Student screen-time analysis project.", "https://github.com/VidyaVGeetha/Student_Scrrentime", "Jupyter Notebook", "2025-04-16"],
  ["Bond_vs_Gold", "Bond versus gold analysis project.", "https://github.com/VidyaVGeetha/Bond_vs_Gold", "Jupyter Notebook", "2025-04-16"],
  ["Inflation_analysis", "Inflation versus 10-year bond yields for the UK, US, Germany, and Canada.", "https://github.com/VidyaVGeetha/Inflation_analysis", "Jupyter Notebook", "2025-04-15"],
  ["GlobalBondWatch", "Global bond market watch analysis project.", "https://github.com/VidyaVGeetha/GlobalBondWatch", "Jupyter Notebook", "2025-04-15"],
  ["Linkedin_search", "Python project related to LinkedIn search automation or analysis.", "https://github.com/VidyaVGeetha/Linkedin_search", "Python", "2025-04-10"],
  ["FeedAnts-Software_Testing", "Software testing assignment project.", "https://github.com/VidyaVGeetha/FeedAnts-Software_Testing", "Testing", "2025-01-23"],
  ["Instagram-Performance-Data-Analysis", "Instagram performance data analysis.", "https://github.com/VidyaVGeetha/Instagram-Performance-Data-Analysis", "Analytics", "2025-03-09"],
  ["Facebook-Performance-Analysis", "Facebook performance dashboard creation.", "https://github.com/VidyaVGeetha/Facebook-Performance-Analysis", "Analytics", "2025-03-09"],
  ["Sending_Email", "Python email automation project.", "https://github.com/VidyaVGeetha/Sending_Email", "Python", "2025-02-23"],
  ["AI", "AI model testing project.", "https://github.com/VidyaVGeetha/AI", "Python", "2024-12-18"]
];

let projects = fallbackProjects.map(([name, description, url, tech, updated]) => ({
  name,
  description,
  url,
  tech,
  updated,
  category: classifyProject(name, description)
}));

function classifyProject(name, description) {
  const text = `${name} ${description}`.toLowerCase();
  if (text.includes("powerbi") || text.includes("power bi") || text.includes("cognos")) return "BI dashboards";
  if (text.includes("sql") || text.includes("sqlite") || text.includes("crime") || text.includes("school") || text.includes("socioeconomic")) return "SQL and public data";
  if (text.includes("regression") || text.includes("prediction") || text.includes("cost") || text.includes("salary") || text.includes("outlier") || text.includes("machine")) return "Predictive analytics";
  if (text.includes("api") || text.includes("scraping") || text.includes("requests") || text.includes("email") || text.includes("linkedin")) return "APIs and automation";
  if (text.includes("dashboard") || text.includes("dash") || text.includes("streamlit") || text.includes("plotly")) return "Python dashboards";
  if (text.includes("visual") || text.includes("wordcloud") || text.includes("waffle") || text.includes("folium") || text.includes("map") || text.includes("immigration")) return "Data visualization";
  return "Business analytics";
}

const projectGrid = document.querySelector("#projectGrid");
const visibleCount = document.querySelector("#visibleCount");
const searchInput = document.querySelector("#searchInput");
const categoryFilter = document.querySelector("#categoryFilter");
const techFilter = document.querySelector("#techFilter");
const categoryOverview = document.querySelector("#categoryOverview");
const totalProjects = document.querySelector("#totalProjects");

function inferTechnology(repo) {
  const text = `${repo.name} ${repo.description || ""}`.toLowerCase();
  if (text.includes("powerbi") || text.includes("power bi")) return "Power BI";
  if (text.includes("cognos")) return "IBM Cognos";
  if (text.includes("testing")) return "Testing";
  if (text.includes("portfolio")) return "Portfolio";
  return repo.language || "Analytics";
}

function fromGitHubRepo(repo) {
  const description = repo.description || "GitHub portfolio project.";
  return {
    name: repo.name,
    description,
    url: repo.html_url,
    tech: inferTechnology(repo),
    updated: (repo.pushed_at || repo.updated_at || repo.created_at || "").slice(0, 10),
    category: classifyProject(repo.name, description)
  };
}

async function fetchGitHubProjects() {
  const repos = [];
  let page = 1;

  while (true) {
    const response = await fetch(`${GITHUB_REPOS_API}&page=${page}`);
    if (!response.ok) {
      throw new Error(`GitHub returned ${response.status}`);
    }

    const pageRepos = await response.json();
    repos.push(...pageRepos);

    if (pageRepos.length < 100) {
      break;
    }
    page += 1;
  }

  return repos
    .filter((repo) => !repo.private && !repo.fork)
    .map(fromGitHubRepo);
}

function setOptions(select, values, firstLabel) {
  const currentValue = select.value;
  select.innerHTML = `<option value="All">${firstLabel}</option>`;
  values.forEach((value) => {
    const option = document.createElement("option");
    option.value = value;
    option.textContent = value;
    select.appendChild(option);
  });
  select.value = values.includes(currentValue) ? currentValue : "All";
}

function renderCategoryOverview() {
  const categories = [...new Set(projects.map((project) => project.category))].sort();
  categoryOverview.innerHTML = categories.map((category) => {
    const count = projects.filter((project) => project.category === category).length;
    return `
      <article>
        <strong>${count}</strong>
        <span>${escapeHTML(category)}</span>
      </article>
    `;
  }).join("");
}

function refreshFilters() {
  const categories = [...new Set(projects.map((project) => project.category))].sort();
  const technologies = [...new Set(projects.map((project) => project.tech))].sort();
  setOptions(categoryFilter, categories, "All classifications");
  setOptions(techFilter, technologies, "All technologies");
}

function escapeHTML(value) {
  return String(value).replace(/[&<>"']/g, (character) => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    "\"": "&quot;",
    "'": "&#39;"
  })[character]);
}

function updateProjectData(nextProjects) {
  projects = nextProjects;
  totalProjects.textContent = projects.length;
  refreshFilters();
  renderCategoryOverview();
  renderProjects();
}

function renderProjects() {
  const search = searchInput.value.trim().toLowerCase();
  const selectedCategory = categoryFilter.value;
  const selectedTech = techFilter.value;

  const filtered = projects.filter((project) => {
    const matchesSearch = !search || `${project.name} ${project.description} ${project.tech} ${project.category}`.toLowerCase().includes(search);
    const matchesCategory = selectedCategory === "All" || project.category === selectedCategory;
    const matchesTech = selectedTech === "All" || project.tech === selectedTech;
    return matchesSearch && matchesCategory && matchesTech;
  });

  visibleCount.textContent = `Showing ${filtered.length} project${filtered.length === 1 ? "" : "s"}`;
  projectGrid.innerHTML = filtered.map((project) => `
    <article class="project-card">
      <div class="project-meta">
        <span>${escapeHTML(project.category)}</span>
        <time datetime="${escapeHTML(project.updated)}">${escapeHTML(project.updated)}</time>
      </div>
      <h3>${escapeHTML(project.name.replaceAll("-", " "))}</h3>
      <p>${escapeHTML(project.description)}</p>
      <div class="card-footer">
        <span>${escapeHTML(project.tech)}</span>
        <a href="${escapeHTML(project.url)}" target="_blank" rel="noreferrer">View project</a>
      </div>
    </article>
  `).join("") || `<p class="empty">No matching projects found.</p>`;
}

[searchInput, categoryFilter, techFilter].forEach((control) => {
  control.addEventListener("input", renderProjects);
});

updateProjectData(projects);

fetchGitHubProjects()
  .then(updateProjectData)
  .catch((error) => {
    console.warn("Using saved project list because GitHub projects could not be loaded.", error);
  });
